<?php

if(!isset($_SESSION)){
    session_start();
    ob_start();
}


$servername = "localhost";
$username = "bmwtatk1_bmwusr";
$password = "s]hc%%j]%8Yz";
$dbname = "bmwtatk1_bmwusr";

// Create connection
$con = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 
?>