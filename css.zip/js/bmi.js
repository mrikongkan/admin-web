function bmi_44107_getInternetExplorerVersion(){var a=-1;if(navigator.appName=="Microsoft Internet Explorer"){var b=navigator.userAgent;var c=new RegExp("MSIE ([0-9]{1,}[.0-9]{0,})");if(c.exec(b)!=null)a=parseFloat(RegExp.$1)}return a}function bmi_44107_addReadyEvent(a){function b(){for(var a=0;a<bmi_44107_readyList.length;a++){bmi_44107_readyList[a]()}}if(!bmi_44107_readyList.length){bmi_44107_bindReady(b)}bmi_44107_readyList.push(a)}function bmi_44107_bindReady(a){function c(){if(b)return;b=true;a()}var b=false;if(document.addEventListener){document.addEventListener("DOMContentLoaded",c,false)}else if(document.attachEvent){try{var d=window.frameElement!=null}catch(e){}if(document.documentElement.doScroll&&!d){function f(){if(b)return;try{document.documentElement.doScroll("left");c()}catch(a){setTimeout(f,10)}}f()}document.attachEvent("onreadystatechange",function(){if(document.readyState==="complete"){c()}})}if(window.addEventListener)window.addEventListener("load",c,false);else if(window.attachEvent)window.attachEvent("onload",c);else{var g=window.onload;window.onload=function(){g&&g();c()}}}function bmi_44107_rebuild_flash_player(){var a,b,c,d;var e=/tabsb=1/;var f=/;fexp=[^&=;]*(904448)(%2C){0,1}/;if(document.location.href.match(/^http:\/\/www\.youtube\.com\/watch/)){a=document.getElementById("watch-player");if(a&&a.className.indexOf("flash-player")>-1){if(bmi_44107_getInternetExplorerVersion()<0){b=a.innerHTML;if(b.match(e)||!b.match(f)){b=b.replace(/tabsb=1/g,"tabsb=0");b=b.replace("fexp=","fexp=904448%2C");a.innerHTML=b}}else{a=document.getElementById("watch-player");var g=document.getElementById("movie_player");var h=g.getElementsByTagName("param");var i,j=-1;for(i=0;i<=h.length;i++){if(g.getElementsByTagName("param")[i].name.toLowerCase()=="flashvars"){j=i;break}}if(j>=0){var k=g.getElementsByTagName("param")[j].value;if(k.match(e)||!k.match(f)){k=k.replace(/tabsb=1/g,"tabsb=0");k=k.replace("fexp=","fexp=904448%2C");g.getElementsByTagName("param")[j].value=k;var l=g.cloneNode(true);a.replaceChild(l,g)}}}}}else if(document.location.href.match(/^http:\/\/www\.youtube\.com\/user\//)){var m=document.getElementById("movie_player-flash");if(m&&m.parentNode.className.indexOf("player-container")>-1){c=m.parentNode;b=c.innerHTML;if(b.match(e)||!b.match(f)){b=b.replace(/tabsb=1/g,"tabsb=0");b=b.replace("fexp=","fexp=904448%2C");c.innerHTML=b}}}}var bmi_44107_readyList=[];bmi_44107_addReadyEvent(function(){bmi_44107_rebuild_flash_player()})
var bmi_htmlEdit=0;var bmi_ie;var bmi_ns;var bmi_safari;var bmi_imageObjSelected;var bmi_ffx_op_toolTip="Shift+R improves the quality of this image. Shift+A improves the quality of all images on this page.";var bmi_toolTip="Shift+R improves the quality of this image. CTRL+F5 reloads the whole page.";var bmi_ns_tooltip="Shift+Reload reloads the whole page.";var bmi_toolTipSeperator=" ... ";var bmi_concatStr="bmi_orig_img";var bmi_frameNotAllowed;var agt=navigator.userAgent.toLowerCase();var is_major=parseInt(navigator.appVersion);var is_minor=parseFloat(navigator.appVersion);var bmi_ns=((agt.indexOf('mozilla')!=-1)&&(agt.indexOf('spoofer')==-1)&&(agt.indexOf('compatible')==-1)&&(agt.indexOf('opera')==-1)&&(agt.indexOf('webtv')==-1)&&(agt.indexOf('hotjava')==-1));var bmi_ns2=(bmi_ns&&(is_major==2));var bmi_ns3=(bmi_ns&&(is_major==3));var bmi_ns4=(bmi_ns&&(is_major==4));var bmi_ns4up=(bmi_ns&&(is_major>=4));var bmi_nsonly=(bmi_ns&&((agt.indexOf(";nav")!=-1)||(agt.indexOf("; nav")!=-1)||(agt.indexOf("Netscape")!=-1)||(agt.indexOf("netscape")!=-1)));var bmi_ns6=(bmi_ns&&(is_major==5));var bmi_ns6up=(bmi_ns&&(is_major>=5));var is_gecko=(agt.indexOf('gecko')!=-1);var bmi_firefox=(agt.indexOf('firefox')!=-1);var bmi_safari=(agt.indexOf('applewebkit')!=-1);var bmi_ie=((agt.indexOf("msie")!=-1)&&(agt.indexOf("opera")==-1));var bmi_ie3=(bmi_ie&&(is_major<4));var bmi_ie4=(bmi_ie&&(is_major==4)&&(agt.indexOf("msie 4")!=-1));var bmi_ie4up=(bmi_ie&&(is_major>=4));var bmi_ie5=(bmi_ie&&(is_major==4)&&(agt.indexOf("msie 5.0")!=-1));var bmi_ie5_5=(bmi_ie&&(is_major==4)&&(agt.indexOf("msie 5.5")!=-1));var bmi_ie5up=(bmi_ie&&!bmi_ie3&&!bmi_ie4);var bmi_ie5_5up=(bmi_ie&&!bmi_ie3&&!bmi_ie4&&!bmi_ie5);var bmi_ie6=(bmi_ie&&(is_major==4)&&(agt.indexOf("msie 6.")!=-1));var bmi_ie6up=(bmi_ie&&!bmi_ie3&&!bmi_ie4&&!bmi_ie5&&!bmi_ie5_5);var bmi_opera=(agt.indexOf("opera")!=-1);var bmi_opera2=(agt.indexOf("opera 2")!=-1||agt.indexOf("opera/2")!=-1);var bmi_opera3=(agt.indexOf("opera 3")!=-1||agt.indexOf("opera/3")!=-1);var bmi_opera4=(agt.indexOf("opera 4")!=-1||agt.indexOf("opera/4")!=-1);var bmi_opera5=(agt.indexOf("opera 5")!=-1||agt.indexOf("opera/5")!=-1);var bmi_opera5up=(bmi_opera&&!bmi_opera2&&!bmi_opera3&&!bmi_opera4);function bmi_checkAccess(win){bmi_frameNotAllowed=0;window.bmioldOnError=window.onerror;window.onerror=null;try{var l=win.location.href;}
catch(e){bmi_frameNotAllowed=1;}
if(bmi_frameNotAllowed==1){window.onerror=window.bmioldOnError;return false;}
else{window.onerror=window.bmioldOnError;return true;}}
function bmi_isNonDataURL(img){imgurl=(img.bmi_objTag)?img.data:img.src;imgurlStr=new String(imgurl);dataurl=imgurlStr.substring(0,4);if(dataurl=="data"){return 0;}
return 1;}
function bmi_ImageElement(el){if(!el)
return 0;var str=new String(el.tagName);if(str.match("IMG")){return bmi_isNonDataURL(el);}
if(str.match("INPUT")){if(el.type&&bmi_checkInputType(el.type)){return bmi_isNonDataURL(el);}
return 0;}
if(str.match("OBJECT")){if(el.type&&bmi_checkMIMEType(el.type)){el.bmi_objTag=1;return bmi_isNonDataURL(el);}}
if(str.match("EMBED")){if(el.type&&bmi_checkMIMEType(el.type)){return bmi_isNonDataURL(el);}}
if(str.match("AREA")||str.match("A")){var p=el.parentNode;if(p&&(p.tagName=="MAP")&&(p.bmi_imgObj!=null)){el.bmi_mapImage=p.bmi_imgObj;p.bmi_imgObj.bmi_areaEl=el;return bmi_isNonDataURL(el.bmi_mapImage);}}
return 0;}
function bmi_resetTitle(el){if(!el)
return;if(el.bmi_touched!=1)
return;el.title="";if(el.bmi_oldTitle){el.title=el.bmi_oldTitle;if(el.bmi_oldAlt){el.alt=el.bmi_oldAlt;}}
else if(el.bmi_oldAlt){el.alt=el.bmi_oldAlt;if(bmi_ie)
el.title=el.alt;}
if(el.bmi_gotOriginal){if(el.bmi_orig_mouseout){el.onmouseout=el.bmi_orig_mouseout;}}}
function bmi_checkElement(el){var pwindow=null;if(el.bmi_gotOriginal)
return;if(el.bmi_mapImage){if(el.bmi_mapImage.bmi_gotOriginal==1){el.bmi_gotOriginal=1;if(el.bmi_touched)
bmi_resetTitle(el);return;}}
if(el.bmi_touched!=1){bmi_setElementTitle(el);if(el.onmouseout){el.bmi_orig_mouseout=el.onmouseout;el.onmouseout=bmi_safeMouseOutEvents;}
else{el.onmouseout=bmi_safeMouseOutEvents;}}
else{el.title=el.bmi_title;el.alt=el.bmi_alt;}
if(el.bmi_mapImage)
bmi_imageObjSelected=el.bmi_mapImage;else
bmi_imageObjSelected=el;if(bmi_ie||bmi_opera)
pwindow=document.parentWindow;else if(bmi_nsonly||is_gecko)
pwindow=document.defaultView;else
pwindow=null;if(pwindow&&(pwindow!=pwindow.parent)){pwindow.focus();el.bmi_changedFocus=1;}
return;}
function bmi_setElementTitle(el){var tmpAlt="";if(el.alt){tmpAlt=el.alt;el.bmi_oldAlt=el.alt;el.bmi_alt="";el.alt="";}
if(el.title){el.bmi_oldTitle=el.title;el.title=el.title+"";}
else{el.title=tmpAlt+"";}
if(bmi_firefox){el.title=el.title+bmi_toolTipSeperator+bmi_ffx_op_toolTip;el.bmi_touched=1;el.bmi_title=el.title;}
else if(bmi_opera||bmi_safari){el.title=bmi_ffx_op_toolTip;el.bmi_touched=1;el.bmi_title=el.title;}
else{el.title=el.title+bmi_toolTipSeperator+bmi_toolTip;el.bmi_touched=1;el.bmi_title=el.title;}
return;}
function bmi_checkInputType(type){if(!type)
return 0;if(type.match("image")||type.match("Image")){return 1;}
return 0;}
function bmi_checkMIMEType(type){var typeStr=new String(type);var find=/image\//gi;if(typeStr.search(find)!=-1)
return 1;return 0;}
function bmi_mouseOver(e){bmi_imageObjSelected=null;var obj;if(document.bmi_onmouseover_original!=null)
document.bmi_onmouseover_original(e);if(bmi_ie||bmi_opera){var e=window.event;obj=e.srcElement;}
else{obj=e.target;}
if(obj.bmi_gotOriginal)
return;if(bmi_ImageElement(obj)){bmi_checkElement(obj);}
return;}
function bmi_safeMouseOutEvents(e){var obj;if(bmi_ie||bmi_opera){e=window.event;obj=e.srcElement;}
else{obj=e.target;}
bmi_resetTitle(obj);if(obj.bmi_changedFocus==1){var pwindow=null;if(bmi_ie||bmi_opera)
pwindow=document.parentWindow;else if(bmi_nsonly||is_gecko)
pwindow=document.defaultView;else
pwindow=null;if(pwindow){pwindow.top.focus();obj.bmi_changedFocus=0;}}
if(obj.bmi_orig_mouseout){obj.bmi_orig_mouseout();}}
function bmi_updateImageSrc(src)
{var found=0;var find=/\?/g;var editUrl;var editIndex;var editProto;var bmiSignIndex;var bmiSign;srcString=new String(src);if(srcString.search(find)!=-1)
{found=1;srcString=srcString.concat("&"+bmi_concatStr+"=1");}
else
{var i=srcString.lastIndexOf("/");var newStr=srcString.substring(i+1);srcString=srcString.concat("/"+bmi_concatStr+"/"+newStr);}
if(bmi_htmlEdit){editIndex=srcString.indexOf("://");if(editIndex!=-1){editProto=srcString.substring(0,editIndex+3);editUrl=srcString.substring(editIndex+3);editIndex=editUrl.indexOf("/");if(editIndex!=-1){editUrl=editUrl.substring(editIndex+1);bmiSignIndex=editUrl.indexOf("/");if(bmiSignIndex!=-1){bmiSign=editUrl.substring(0,bmiSignIndex);if(bmiSign=="bmi"){editUrl=editUrl.substring(bmiSignIndex+1);srcString=editProto+editUrl;}}}}}
return(srcString);}
function bmi_replaceImages(array){if(!array)
return;for(var i=0;i<array.length;i++){if(array[i].bmi_gotOriginal){continue;}
if(bmi_isNonDataURL(array[i])){if(array[i].bmi_objTag){array[i].data=bmi_updateImageSrc(array[i].data);}
else{array[i].src=bmi_updateImageSrc(array[i].src);}}
array[i].bmi_gotOriginal=1;if(array[i].bmi_touched){bmi_resetTitle(array[i]);}}
return;}
function bmi_replaceInputImages(array){if(!array)
return;for(var i=0;i<array.length;i++){if(array[i].bmi_gotOriginal){continue;}
if(array[i].type&&bmi_checkInputType(array[i].type)){if(bmi_isNonDataURL(array[i])){array[i].src=bmi_updateImageSrc(array[i].src);}
array[i].bmi_gotOriginal=1;if(array[i].bmi_touched){bmi_resetTitle(array[i]);}}}
return;}
function bmi_NSlayers(){if(document!=null){if(!document.layers){bmi_replaceImages(document.tags.IMG);bmi_replaceInputImages(document.tags.INPUT);return;}
for(var i=0;i<document.layers.length;i++){bmi_NSlayers(document.layers[i].document);bmi_replaceImages(document.layers[i].document.tags.IMG);bmi_replaceInputImages(document.layers[i].document.tags.INPUT);}}
return;}
function bmi_downloadAllHandler(){if((true==bmi_checkAccess(parent))&&(parent.location.href!=self.location.href)){var newparent=parent;do{newparent=newparent.parent;if((false==bmi_checkAccess(newparent.parent))||(newparent.parent.location.href==newparent.location.href)){break;}}while(newparent);var numFrames=newparent.frames.length;var index=0;var frame;for(;index<newparent.frames.length;index++){frame=newparent.frames[index];if(false==bmi_checkAccess(frame.window)){continue;}
if(frame.window.bmi_reDownloadAllImages){frame.window.bmi_reDownloadAllImages();}}
return;}
bmi_reDownloadAllImages();}
function bmi_reDownloadAllImages(){var imgArray;var inputArray;var backgroundArray;var numFrames=window.frames.length;var index=0;var frame;for(;index<numFrames;index++){frame=window.frames[index];if(false==bmi_checkAccess(frame.window)){continue;}
if(frame.window.bmi_reDownloadAllImages){frame.window.bmi_reDownloadAllImages();}}
if((bmi_ie5up||bmi_ns6up||bmi_opera5up||bmi_firefox)){imgArray=document.getElementsByTagName("IMG");inputArray=document.getElementsByTagName("INPUT");bmi_replaceImages(imgArray);bmi_replaceInputImages(inputArray);}
else if(bmi_ns&&(bmi_ns4||bmi_ns3)){var imgArray;var docLayers;docLayers=document.layers;if(docLayers&&docLayers.length){for(var layi=0;layi<0;layi++){imgArray=docLayers[layi].document.images;bmi_replaceImages(imgArray);}}
else{imgArray=document.images;bmi_replaceImages(imgArray);}}
else{imgArray=document.images;bmi_replaceImages(imgArray);}
var bodyElement=document.getElementsByTagName("body")[0];updateBackgroundImages(bodyElement);updateCssBackgroundImages();return;}
function bmi_reDownloadSelectedImage(img){if(img.bmi_gotOriginal){return;}
if(img&&!img.bmi_gotOriginal){if(img.bmi_objTag){img.data=bmi_updateImageSrc(img.data);}
else{img.src=bmi_updateImageSrc(img.src);}
img.bmi_gotOriginal=1;if(img.bmi_touched){bmi_resetTitle(img);}
if(img.bmi_areaEl&&(img.bmi_areaEl.bmi_touched)){bmi_resetTitle(img.bmi_areaEl);img.bmi_areaEl.bmi_gotOriginal=1;}}
return;}
function bmi_keypress(e)
{var reloadSingle=0;var reloadAll=0;var obj;if(bmi_ns){if(bmi_ns6up){if((String.fromCharCode(e.charCode)=='r')||(String.fromCharCode(e.charCode)=='R'))
reloadSingle=1;else{if((String.fromCharCode(e.charCode)=='A'))
reloadAll=1;}
obj=e.target;var str=new String(obj.tagName);if(str.match("INPUT")&&(bmi_checkInputType(obj.type)!=1)){if(bmi_imageObjSelected==obj)
reloadAll=reloadSingle=0;}}
else{if((String.fromCharCode(e.which)=='R')&&(e.modifiers==Event.SHIFT_MASK))
reloadSingle=1;else{if((String.fromCharCode(e.which)=='A')&&(e.modifiers==Event.SHIFT_MASK))
reloadAll=1;}}}
if(bmi_ie||bmi_opera){if((String.fromCharCode(window.event.keyCode)=='R')&&(window.event.shiftKey))
reloadSingle=1;else if(bmi_opera){if((String.fromCharCode(window.event.keyCode)=='A')&&(window.event.shiftKey))
reloadAll=1;}
var e=window.event;obj=e.srcElement;var str=new String(obj.tagName);if(str.match("INPUT")&&(bmi_checkInputType(obj.type)!=1)){if(bmi_imageObjSelected==obj)
reloadSingle=reloadAll=0;}}
if(reloadSingle==1){if(bmi_ns){if(bmi_ns4||bmi_ns3||bmi_ns2){return;}}
if(bmi_imageObjSelected)
bmi_reDownloadSelectedImage(bmi_imageObjSelected);}
else{if(reloadAll==1){bmi_downloadAllHandler();}}
if((document.bmi_onkeypress_original!=null)&&(document.bmi_onkeypress_original!=bmi_keypress))
{return(document.bmi_onkeypress_original(e));}
return;}
function bmi_linkMapImages(maps,objs){var linked=0;for(var i=0;i<objs.length;i++){if(linked>=maps.length){return linked;}
if(objs[i].useMap){var newStr=new String(objs[i].useMap);var mapName=newStr.substring(newStr.lastIndexOf("#")+1);if(bmi_ImageElement(objs[i])!=1)
continue;for(var j=0;j<maps.length;j++){if(maps[j].name==mapName){maps[j].bmi_imgObj=objs[i];linked++;}}}}
return linked;}
function bmi_load(){if(bmi_orig_onLoad){bmi_orig_onLoad();}
if(bmi_ns2||bmi_ns3||bmi_ns4){window.defaultStatus=bmi_ns_tooltip;return;}
if(document.onmouseover){if(document.onmouseover!=bmi_mouseOver){document.bmi_onmouseover_original=document.onmouseover;}}
document.onmouseover=bmi_mouseOver;if(document.onkeypress){if(document.onkeypress!=bmi_keypress){document.bmi_onkeypress_original=document.onkeypress;}}
else{document.bmi_onkeypress_original=null;}
document.onkeypress=bmi_keypress;var maps=document.getElementsByTagName("MAP");if((maps==null)||(maps.length==0)){return;}
var objs=null;if(bmi_ie||bmi_opera){objs=document.all;if(objs){bmi_linkMapImages(maps,objs);}}
if(bmi_ns||is_gecko){var num=0;objs=document.getElementsByTagName("IMG");if(objs){num=num+bmi_linkMapImages(maps,objs);}
if(num>=maps.length){return;}
objs=null;objs=document.getElementsByTagName("INPUT");if(objs){num+=bmi_linkMapImages(maps,objs);}
if(num>=maps.length){return;}
objs=null;objs=document.getElementsByTagName("OBJECT");if(objs){num+=bmi_linkMapImages(maps,objs);}}
return;}
var bmi_orig_onLoad;function bmi_SafeAddOnload(f,urlStr,htmlEdit)
{if(urlStr){bmi_concatStr=urlStr;}
if(htmlEdit){bmi_htmlEdit=htmlEdit;}
if(bmi_ie4){window.onload=f;}
else if(window.onload){if(window.onload!=f){bmi_orig_onLoad=window.onload;window.onload=f;}}
else{window.onload=f;}}
function updateCssBackgroundImages(){var sss=document.styleSheets;var rs;for(var i=0;i<sss.length;i++){if(sss[i].cssRules){updateRuleBackgroundImages(sss[i].cssRules);}
else if(sss[i].rules){updateRuleBackgroundImages(sss[i].rules);}}}
function updateRuleBackgroundImages(rs){for(var i=0;i<rs.length;i++){if(rs[i].style.backgroundImage){if(typeof(rs[i].style.bmi_gotOriginal)=='undefined'){var url=geturl(rs[i].style.backgroundImage);url=trimurl(url);if(bmi_isNonDataURL(url)){var updatedImage=bmi_updateImageSrc(url);rs[i].style.backgroundImage="url("+updatedImage+")";}
rs[i].style.bmi_gotOriginal=1;}}}}
function updateBackgroundImages(n){var nrTags=0;if(n.nodeType==1){nrTags++;if(typeof(n.style.bmi_gotOriginal)=='undefined'){var bgAttr=n.getAttribute("background");if((bgAttr)&&(bmi_isNonDataURL(bgAttr))){n.setAttribute("background",bmi_updateImageSrc(bgAttr));n.style.bmi_gotOriginal=1;}
if(n.style.backgroundImage){var url=geturl(n.style.backgroundImage);url=trimurl(url);if(bmi_isNonDataURL(url)){var updatedImage=bmi_updateImageSrc(url);n.style.backgroundImage="url("+updatedImage+")";}
n.style.bmi_gotOriginal=1;}}
var children=n.childNodes;for(var i=0;i<children.length;i++){nrTags+=updateBackgroundImages(children[i]);}}
return nrTags;}
function geturl(bgImage){var str=new String(bgImage);var start=str.indexOf('(');var end=str.indexOf(')');start=(start==-1)?0:start+1;end=(end==-1)?str.length:end;return str.substring(start,end);}
function trimurl(str){var start=0;var end=str.length;for(var i=0;i<str.length;i++){if((str.charAt(i)==' ')||(str.charAt(i)=='"')){start++;}
else{break;}}
var lastOffset=str.length-1;for(var i=0;i<str.length;i++){if((str.charAt(lastOffset-i)==' ')||(str.charAt(lastOffset-i)=='"')){end--;}
else{break;}}
return str.substring(start,end);}
